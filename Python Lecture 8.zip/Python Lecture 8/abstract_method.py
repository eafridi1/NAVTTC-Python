from abc import ABC,abstractmethod

class Student(ABC):
    def __init__(self,name,ID):
        self.name = name
        self.ID = ID
        self.grades = []
    @abstractmethod
    def calculate_grade_point_average(self):
        pass    
    def display_info(self):
        pass   
    def save_to_file(self,filename):
        pass
    @abstractmethod
    def load_from_file(self,filename):
        pass    

        
    