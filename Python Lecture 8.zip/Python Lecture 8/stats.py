# import numpy as np
# import statistics as st

# raindata = [2,5,4,4,0,2,7,8,8,8]
# x = ("mean =",st.mean(raindata))

# print(x)

# y = ("median = ", st.median(raindata))
# print(y)

# z= ("mode =", st.mode(raindata))
# print(z)

# a = ("variance is =", st.variance(raindata))
# print(a)


# b = ("population variance ", st.pvariance(raindata))
# print(b)


# c =("standard deviation =",st.stdev(raindata))
# print(c)

# d = ("population standard deviation = ", st.pstdev(raindata))
# print(d)

# s = 'GEEKSFORGEEKS'
# print(s.isupper())

# s = 'GeeksforGeeks'
# print(s.isupper())

# a = "geeksforgeeks"
# print(a.islower())

# s = 'GeeksforGeeks'
# print(s.islower())

# s = 'GEEKSFORGEEKS'
# print(s.lower()) 
# print()
# s = 'GeeksforGeeks'
# print(s.lower())

# s = 'geeksforgeeks'
# print(s.upper()) 

# s = 'My name is EA'
# print(s.upper())

# s = 'GeeksforGeeks is a computer Science portal for Geeks'
# ns = ''
# cu = 0
# cl = 0
# cs = 0

# for ch in s:
#     if ch.isupper():
#         cu += 1
#         ns += ch.lower()
#     elif ch.islower():
#         cl += 1
#         ns += ch.upper()
#     elif ch.isspace():
#         cs += 1
#         ns += ch

# print("In original String:")
# print("Uppercase -", cu)
# print("Lowercase -", cl)
# print("Spaces -", cs)
# print("After changing cases:")
# print(ns)

# x = 1
# y=0
# print(x!=y)


# x = "Hello world" # x is a string of characters
# print("H"in x) # returns True if ‘H’ is in x
# print("Hello" not in x) # returns True if ‘Hello’ is not

# mystr1 = "Statistics "
# mystr2 = "using"
# mystr3 = " Python"
# print(mystr1 + mystr2+ mystr3)

# x = 'This is a test string'
# print(x[8:len(x)])

# print(x[-1])


x = 'This is a test string'
x[1:12:2]
print(x)

x = 'This is a test string'
x[:0:-2]
print(x)
#page 49 tk

print(x[8:len(x)])

x = 'This is a test string'
x[1:12:2]
print(x)

x = 'This is a test string'
x[:0:-2]
print(x)