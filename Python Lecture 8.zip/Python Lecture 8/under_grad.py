from abstract_method import Student
class UndergraduateStudent(Student):
    def __init__(self, name, ID, courses):
        super().__init__(self,name, ID)
        self.courses = courses
    def calculate_grade_point_average(self):
        total_grades_points = 0
        total_credit_hours = 0

        for grade,credits in self.courses:
            grade_upper = grade.upper()
            if grade_upper in self.grade_point_map:
                total_grades_points +=  self.grade_point_map[grade_upper]*credits
                total_credit_hours += credits
            else:
                print(f"invalid grade '{grade}' encountered skipping") 
                   