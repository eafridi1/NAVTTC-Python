from UGS import UndergraduateStudent
from UGS import GraduateStudent

ugs = UndergraduateStudent("Khubaib", 15147,5)
ugs.grades = [4.0,4.0,4.0,4.0,3.5,4.0]
ugs.save_to_file("UGS.txt")
ugs.load_from_file("UGS.txt")
print(ugs.display_information())
gs = GraduateStudent("HM Tehreem", 5328, "Self Driving Cars")
gs.grades = [3.33,3.33,3.67]
gs.save_to_file("gs.txt")
gs.load_from_file("gs.txt")
gs.display_information()
print(gs)
