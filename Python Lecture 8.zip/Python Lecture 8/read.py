# f = open("demo.txt")

# f = open("demo.txt","rt")
# print()
# print(f.read()) 
# print()


# with open("demo.txt") as f:
#   print(f.read())


# f = open("demo.txt")
# print(f.readline())
# f.close()
# print("file closed")
# print()

# f = open("demo.txt")
# print(f.read(7))

# print()

# with open("demo.txt") as f:
#   print(f.readline())
#   print(f.readline())

# with open("demo.txt") as f:
#   for x in f:
#     print(x)

# with open("demo.txt", "a") as f:
#   f.write("\nNow the file has more content!")

# #open and read the file after the appending:
# with open("demo.txt") as f:
#   print(f.read())

# with open("demo.txt", "w") as f:
#   f.write("Woops! I have deleted the content!")

# #open and read the file after the overwriting:
# with open("demo.txt") as f:
#   print(f.read())

# f = open("myfile.txt", "x")

# import os
# os.remove("myfile.txt")
# print("file deleted")

# import os
# if os.path.exists("demo.txt"):
#   os.remove("demo.txt")
# else:
#   print("The file does not exist")
# import os
# os.rmdir("empty")
# print("folder deleted")

import os
os.remove("Abstraction.ipynb")
print("file deleted")

