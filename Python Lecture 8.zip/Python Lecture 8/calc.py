add = 3+10-6
print(add)

minus = 30-5*8
print(minus)

mix = (30-5*8)/5
print(mix)


div = 20/8
print(div)

div2 = 20//8
print(div2)

mod = 20%6
print(mod)

power = 3**4
print(power) 

a = type(5*4.6)
print(a)

a = 2+7j
print(a)

b= ~4+1
print("b",b)
x = 7
y = 1
z = x & y
print(z)

f= x&y
print("f",f)

g = x|y
print(g)

c = ~x
print(c)

d = x^y
print("d",d)

y >> 2
print("y",y)

x<<3
print(x)

marks1 = 75
marks2 = 85
print(marks1+marks2)

my_var = 10
my_var+=20
print(my_var)


