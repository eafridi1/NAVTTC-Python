from abstract_method import Student

class UndergraduateStudent(Student):
    def __init__(self, name, ID, courses_taken):
        Student().__init__(self,name, ID)
        self.courses_taken = courses_taken
class GraduateStudent(Student):
    def __init__(self, name, ID, courses_taken):
        Student().__init__(self,name, ID)
        self.courses_taken = courses_taken
    def calculate_grade_point_average(self):
        return sum(self.grades)/len(self.grades)
    def display_info(self):
        print(f"Undergraduate Student: {self.name},ID: {self.ID},GPA: {self.calculate_grade_point_average()}")
    def save_to_file(self, filename):
        with open(filename, "w") as file:
            file.write(f"{self.name}, {self.ID}, {','.join(map(str, self.grades))}\n")
    def load_from_file(self, filename):
        with open(filename, "r") as file:
            line = file.readline()
            name, ID, *grades = line.strip().split(',')

            self.name = name
            self.ID = ID
            self.grades = list(map(float, grades))